import React from 'react';
import logo from './logo.svg';
import './App.css';
import MovieSearchComponent from './Component/MovieSearchComponent'

function App() {
  return (
    <MovieSearchComponent/>
  );
}

export default App;
